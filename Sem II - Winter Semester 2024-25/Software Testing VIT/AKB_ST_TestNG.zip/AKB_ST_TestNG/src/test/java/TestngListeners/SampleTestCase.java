package TestngListeners;

import org.testng.annotations.Test;

public class SampleTestCase {
    @Test
    public void test() {
        System.out.println("Hello World, This is TestNG");
    }
}
