package ParallelTestExecution;

import org.testng.annotations.Test;

public class ParallelEx3 {
    @Test
    public void StudentLogin(){
        System.out.println("Student Login");
    }
    @Test
    public void StudentDetails(){
        System.out.println("Student Details");
    }

}
